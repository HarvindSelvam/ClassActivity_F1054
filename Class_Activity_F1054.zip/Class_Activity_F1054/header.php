<!DOCTYPE html>
<html>
<head>
<h1><center>Registration Form</center></h1>
</head>
<body style="background-color:powderblue;">	
</body>
</html>